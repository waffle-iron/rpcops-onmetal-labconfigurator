#ifndef VPORT_VXLAN_H
#define VPORT_VXLAN_H 1

#include <linux/kernel.h>
#include <linux/types.h>

struct ovs_vxlan_opts {
	__u32 gbp;
};

#endif
